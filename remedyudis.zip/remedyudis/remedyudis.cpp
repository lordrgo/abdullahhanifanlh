#include "remedyudis.h"

void createList(List &L) {
    first(L) = NULL; last(L) = NULL;
}

address createElm(int id, string nama, string status) {
    address P = new elmList;
    info(P).id = id;
    info(P).nama = nama;
    info(P).status = status;
    next(P) = NULL;

    return P;
}

void insertLast(List &L, address P) {
    if (first(L)==NULL && last(L)==NULL) {
        first(L) = P; last(L) = P;
    } else {
        next(last(L)) = P;
        last(L) = P;
    }
}

void updateList(List &L, string nama) {
    address Prec;
    Prec = findElm(L, nama);

    if (Prec!=NULL) {
        if (info(Prec).status == "Kontrak") {
            info(Prec).status = "Tetap";
        } else if (info(Prec).status == "Tetap") {
            info(Prec).status = "Kontrak";
        }
        cout<<"Data sudah diubah."<<endl;
    } else {
        cout<<"Tidak ada data yang diubah."<<endl;
    }
}

address findElm(List L, string nama) {
    address P = first(L);
    while (P!=NULL) {
        if (info(P).nama==nama) {
            return P;
        }
        P = next(P);
    }
    cout<<"Nama tidak ditemukan."<<endl;;
    return NULL;
}

void infoList(List L) {
    address P = first(L);

    while(P!=NULL) {
        cout<<info(P).id<<endl;
        cout<<info(P).nama<<endl;
        cout<<info(P).status<<endl;
        cout<<endl;

        P = next(P);
    }

    cout<<"End List."<<endl<<endl;
}
