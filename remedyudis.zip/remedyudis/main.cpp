#include <iostream>
#include "remedyudis.h"
using namespace std;

int main()
{
    List L;
    address P;

    createList(L);
    P = createElm(1, "Ronaldo", "Tetap");
    insertLast(L, P);
    P = createElm(2, "Alves", "Kontrak");
    insertLast(L, P);
    P = createElm(3, "Puyol", "Tetap");
    insertLast(L, P);
    P = createElm(4, "Rodrigo", "Kontrak");
    insertLast(L, P);

    infoList(L);
    updateList(L, "Ronaldo");
    infoList(L);

    return 0;
}
