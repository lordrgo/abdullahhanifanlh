#ifndef REMEDYUDIS_H_INCLUDED
#define REMEDYUDIS_H_INCLUDED
#include <iostream>
#include <stdlib.h>
using namespace std;

#define first(L) ((L).first)
#define last(L) ((L).last)
#define info(P) (P)->info
#define next(P) (P)->next

typedef struct elmList *address;
struct data {
    int id;
    string nama, status;
};
typedef data infotype;

struct elmList {
    infotype info;
    address next;
};

struct List {
    address first;
    address last;
};

void createList(List &L);
address createElm(int id, string nama, string status);
void insertLast(List &L, address P);
void updateList(List &L, string nama);
address findElm(List L, string nama);
void infoList(List L);

#endif // REMEDYUDIS_H_INCLUDED
